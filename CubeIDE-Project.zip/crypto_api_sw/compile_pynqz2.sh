make build-lib-openssl
make build-alt
make uninstall-lib-openssl
make uninstall-alt
make install-lib-openssl
make install-alt