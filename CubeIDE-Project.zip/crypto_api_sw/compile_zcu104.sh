make build-openssl
make build-alt
make uninstall-openssl
make uninstall-alt
make install-openssl
make install-alt