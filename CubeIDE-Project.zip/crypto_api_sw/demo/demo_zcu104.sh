export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/xilinx/crypto_api_sw/CRYPTO_API_SW/build
make demo-all-openssl
make demo-all-alt
make demo-build-openssl
make demo-build-alt
make demo-install-openssl
make demo-install-alt
make demo-speed-all-openssl
make demo-speed-all-alt
make demo-speed-build-openssl
make demo-speed-build-alt
make demo-speed-install-openssl
make demo-speed-install-alt
./demo-all-openssl
./demo-all-alt
./demo-build-openssl
./demo-build-alt
./demo-install-openssl
./demo-install-alt 
./demo-speed-all-openssl
./demo-speed-all-alt
./demo-speed-build-openssl
./demo-speed-build-alt
./demo-speed-install-openssl
./demo-speed-install-alt
