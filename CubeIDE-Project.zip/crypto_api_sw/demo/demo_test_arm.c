
#include "demo_arm.h"
#include "../crypto_api_sw.h"

void main() {
	
	demo_arm(2);

}