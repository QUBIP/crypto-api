export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/eros/Share/crypto_api_sw/CRYPTO_API_SW/build
make demo-all-openssl
make demo-all-mbedtls
make demo-all-alt
make demo-build-openssl
make demo-build-mbedtls
make demo-build-alt
make demo-install-openssl
make demo-install-mbedtls
make demo-install-alt
make demo-speed-all-openssl
make demo-speed-all-mbedtls
make demo-speed-all-alt
make demo-speed-build-openssl
make demo-speed-build-mbedtls
make demo-speed-build-alt
make demo-speed-install-openssl
make demo-speed-install-mbedtls
make demo-speed-install-alt
./demo-all-openssl
./demo-all-mbedtls
./demo-all-alt
./demo-build-openssl
./demo-build-mbedtls
./demo-build-alt
./demo-install-openssl
./demo-install-mbedtls
./demo-install-alt 
./demo-speed-all-openssl
./demo-speed-all-mbedtls
./demo-speed-all-alt
./demo-speed-build-openssl
./demo-speed-build-mbedtls
./demo-speed-build-alt
./demo-speed-install-openssl
./demo-speed-install-mbedtls
./demo-speed-install-alt
